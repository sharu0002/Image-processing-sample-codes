
public class Contrast_Image {
    public static int getMax(int[][] inputArray){ 
    int maxValue = inputArray[0][0]; 
    for(int i=0;i < inputArray.length;i++){
    for(int j=0;j<inputArray[0].length;j++){ 
      if(inputArray[i][j] > maxValue){ 
         maxValue = inputArray[i][j]; 
      } 
    } 
}
    return maxValue; 
  }

  public static int getMin(int[][] inArray){ 
    int minValue = inArray[0][0]; 
    for(int i=0;i < inArray.length;i++)
    {
    for(int j=0;j<inArray[0].length;j++)
    { 
      if(inArray[i][j] < minValue){ 
         minValue = inArray[i][j]; 
      } 
    } 
}
    return minValue; 
  }

 
	public static void printMatrix(int[][] matrix) {
       int rows = matrix.length;
       int columns = matrix[0].length;
       for (int i = 0; i < rows; i++) {
           for (int j = 0; j < columns; j++) {
               System.out.print(matrix[i][j] + " ");
           }
           System.out.println();
       }
}

public static int[][] contras_s(int[][] im){
	
	int rows = im.length;
       int columns = im[0].length;
       double result[][] = new double[rows][columns];
	int max=getMax(im);
	int min=getMin(im);
        System.out.println("max:    "+max+"   min:   "+min);
	for(int i=0;i<rows;i++){
		for(int j=0;j<columns;j++){
			result[i][j]=(((double)im[i][j]-min)/(max-min))*255;
		}
	} 
        int ret[][]=new int[rows][columns];
	System.out.println("After Contrast..................");
	for (int i = 0; i < rows; i++) {
           for (int j = 0; j < columns; j++) {
               System.out.print((int)result[i][j] + " ");
               ret[i][j]=(int)Math.round(result[i][j]);
           }
           System.out.println();
       }
        return ret;
    }
    
}
