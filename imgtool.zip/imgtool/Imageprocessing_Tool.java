


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SpringLayout;


public class Imageprocessing_Tool extends JFrame implements ActionListener{

public static int [][]grayPixVal;
public static int h,w,valcon;
public static int width;
public static int height;
int count = 0;
//public static int [][]pixv;

    RescaleOp rescale;
    ImageIcon icon;
    JLabel picLabel=new JLabel();

    private JMenuBar mnu_bar;
    private JMenu mnu_file,mnu_arit,mnu_enh,mnu_mask;
    private JMenuItem  mnu_open, mnu_exit,mnu_add,mnu_bri,mnu_cont,mnu_size;
    private JTextField txt_add;
    private JLabel lbl_add;

 BufferedImage image;
 
 JFrame frame = new JFrame("Image");
  JPanel panel = new JPanel();
  
 Imageprocessing_Tool(String title){

        super(title);
        
        Container contentPane = getContentPane();
        
        lbl_add=new JLabel("Enter no. to add to image");

       txt_add=new JTextField(10);
       
        // panel.setLayout(new SpringLayout());
 
        panel.add(lbl_add);
        panel.add(txt_add);
        
        mnu_bar = new JMenuBar();
        //file menu

        mnu_file = new JMenu("File");
        mnu_arit=new JMenu("Arithmetic");
        mnu_enh=new JMenu("Enhancement");
        mnu_mask=new JMenu("Masking");
       
        
        
        //file
        mnu_open = new JMenuItem("Open");
        mnu_open.addActionListener(this);
        mnu_exit = new JMenuItem("Close");
        mnu_exit.addActionListener(this);
        
      
        
        
        //items
        mnu_add = new JMenuItem("Add");
        mnu_add.addActionListener(this);
        mnu_bri = new JMenuItem("Brightening");
        mnu_bri.addActionListener(this);
        mnu_cont = new JMenuItem("Contrast Stretching");
        mnu_cont.addActionListener(this);
        mnu_size=new JMenuItem("smoothening 3");
        mnu_size.addActionListener(this);
        
        //adding to file
        mnu_file.add(mnu_open);
        mnu_file.addSeparator();
        mnu_file.add(mnu_exit);
        
        //arith
        mnu_arit.add(mnu_add);
        
        //enh
        mnu_enh.add(mnu_bri);
        mnu_enh.add(mnu_cont);
        
        //mask
        mnu_mask.add(mnu_size);
        
       
        
        //bar
        mnu_bar.add(mnu_file);
        mnu_bar.add(mnu_arit);
        mnu_bar.add(mnu_enh);
        mnu_bar.add(mnu_mask);
       
        
        setJMenuBar(mnu_bar);
        
       
        contentPane.add(new JScrollPane(), BorderLayout.CENTER);
       getContentPane().add(panel);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setSize(500,550);
        setVisible(true);
        
        
 }
 public void rescale() {

        rescale = new RescaleOp(1.0f,120.0f, null);
        image=rescale.filter(image,null);//(sourse,destination)

    }
        
    @Override
    public void actionPerformed(ActionEvent e) {
         if(e.getSource()==mnu_exit) {
            System.exit(0);
         }
         
         if(e.getSource()==mnu_open){
             try{
				
		JFileChooser fc = new JFileChooser("C:\\Users\\hp\\Pictures\\lab");
            fc.showOpenDialog(this);
            File f = fc.getSelectedFile();
            
           ImagePanel shim= new ImagePanel("f");
            shim.loadImage(f.getAbsolutePath());
                h=shim.getHeightpix();
                w=shim.getWidthpix();
                System.out.println("Size of Image M X N:  "+h+"   "+w);
               grayPixVal=new int[h][w];
               grayPixVal=shim.getPixelVal(); 
                image = ImageIO.read(f);
			}catch(Exception e1){}
             
         }
         
         if(e.getSource()==mnu_add){
             Add_op ad= new Add_op();
             valcon= Integer.parseInt(txt_add.getText());
             int [][] cont =ad.add_pixels(grayPixVal,valcon);
             
             try{
                int width = cont[0].length;
                int height = cont.length;

               image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

               for(int i=0; i<height; i++){

                 for(int j=0; j<width; j++){
                   int u = (int)cont[i][j];
                        int p = (u<<24) | (u<<16) | (u<<8) | u; //pixel 
  
                 image.setRGB(j,i,p);
             }
          }

          File ouptut = new File("C:\\Users\\hp\\Pictures\\lab\\addimage.jpg");
          ImageIO.write(image, "jpg", ouptut);
          try{
				
				ImageIcon icon = new ImageIcon(ouptut.getAbsolutePath());
				JFrame frame = new JFrame("add");
				frame.setLayout(new FlowLayout());
				frame.setSize(w+30,h+30);
				JLabel lbl = new JLabel();
				lbl.setIcon(icon);
				frame.setVisible(true);
				JPanel panel = new JPanel();
				panel.add(lbl);
  				panel.repaint(); 
				frame.add(panel);
				show();

				
				

			}catch(Exception e3){}  

       }
       catch (Exception exc){}
             grayPixVal=cont;
         }
         
         if(e.getSource()==mnu_cont){
             Contrast_Image contras=new Contrast_Image();
             System.out.println("con entered............");
             int cont[][]=contras.contras_s(grayPixVal);
             grayPixVal=cont;
             try{
                int width = cont[0].length;
                int height = cont.length;

               image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

               for(int i=0; i<height; i++){

                 for(int j=0; j<width; j++){
                   int u = (int)cont[i][j];
                        int p = (u<<24) | (u<<16) | (u<<8) | u; //pixel 
  
                 image.setRGB(j,i,p);
             }
          }

          File ouptut = new File("C:\\Users\\hp\\Pictures\\lab\\Contrastimage.jpg");
          ImageIO.write(image, "jpg", ouptut);
          try{
				
				ImageIcon icon = new ImageIcon(ouptut.getAbsolutePath());
				JFrame frame = new JFrame("Contrast");
				frame.setLayout(new FlowLayout());
				frame.setSize(w+30,h+30);
				JLabel lbl = new JLabel();
				lbl.setIcon(icon);
				frame.setVisible(true);
				JPanel panel = new JPanel();
				panel.add(lbl);
  				panel.repaint(); 
				frame.add(panel);
				show();
				
				
				

			}catch(Exception e3){}  

       }
       catch (Exception exc){}
           
             
         }
         if(e.getSource()==mnu_size){
             Mask_op maop=new Mask_op();
             int [][]cont=maop.Maskop(grayPixVal);
             grayPixVal=cont;
             try{
                int width = cont[0].length;
                int height = cont.length;

               image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

              
               for(int i=0; i<height; i++){

                 for(int j=0; j<width; j++){
                      Color c=new Color(grayPixVal[i][j]);
                   int u = (int)cont[i][j]*3;
                        int p = (u<<24) | (u<<16) | (u<<8) | u; //pixel 
  
                        
                 image.setRGB(j,i,p);
             }
          }

          File ouptut = new File("C:\\Users\\hp\\Pictures\\lab\\mask.jpg");
          ImageIO.write(image, "jpg", ouptut);
          try{
				
				ImageIcon icon = new ImageIcon(ouptut.getAbsolutePath());
				JFrame frame = new JFrame("Masking");
				frame.setLayout(new FlowLayout());
				frame.setSize(w+30,h+30);
				JLabel lbl = new JLabel();
				lbl.setIcon(icon);
				frame.setVisible(true);
				JPanel panel = new JPanel();
				panel.add(lbl);
  				panel.repaint(); 
				frame.add(panel);
				show();
			
				
				

			}catch(Exception e3){}  

       }
       catch (Exception exc){}
             
         }
         if(e.getSource()==mnu_bri){
             rescale();
         	icon = new ImageIcon(image);          
         	picLabel.setIcon(icon); 
         	System.out.println("offset : "+120.0f  );
         	if(image!=null){
			try{
				File output = new File("bright.jpg");
				ImageIO.write(image,"jpg",output);
				ImageIcon icon = new ImageIcon(output.getAbsolutePath());
				JFrame frame = new JFrame("Brightening");
				frame.setLayout(new FlowLayout());
				frame.setSize(w+30,h+30);
				JLabel lbl = new JLabel();
				lbl.setIcon(icon);
				frame.setVisible(true);
				JPanel panel = new JPanel();
				panel.add(lbl);
  				panel.repaint(); 
				frame.add(panel);
				show();
				
				
				

			}catch(Exception e3)
			{}
                
                }
         }
         
       }
    
}
