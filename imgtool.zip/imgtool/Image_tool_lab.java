public class Image_tool_lab {

    public static void main(String[] args) {
        new Imageprocessing_Tool("imaging Tool");
        
    }
    
}