
public class Mask_op {
    
    public int [][]Maskop(int [][]image){
	int rows = image.length;
       int columns = image[0].length;
		
		
		 
		
		
                 System.out.println("the output =");
                 int m=7;
                  int ima[][]=new int[rows][columns];
                 
                int[][]lpfre= lpf(image,ima,rows,columns,m);
                 
                return lpfre; 
        
    }
    
    
    
    public int[][] lpf(int p1[][], int p2[][], int width, int height, int maskSize){ 
   int w = width;
  int h=height;
  int max = 0, i=0, j=0;
  int start = maskSize/2;
  int size = maskSize*maskSize;
  int sum=0; 
    try{ 
      for(i = start; i < h-start; i++){
          for(j = start; j < w-start; j++){
              sum=0;
      
 
    for(int k = -1*start; k < (start+1); k++){
        for(int l = -1*start; l < (start+1); l++){
            //System.out.println("k = " + k + " l = " + l);      
            sum += p1[i+k][j+l];     
                }
    }
        p2[i][j] = sum/size; 
        } 
    } 
   for(i = 0; i < h; i++)   
      for(j = 0; j < w; j++)   
          if(i==0||j==0||i==h-1||j==w-1) 
              p2[i][j] = p1[i][j]; 
  }
  catch(Exception e)
  {
      System.out.println("E i = " + i + " j = " + j);
  }
   System.out.println();
	for ( i = 0; i < w; i++) {
           for ( j = 0; j < h; j++) {
               System.out.print((int)p2[i][j] + " ");
           }
           System.out.println();
       }
        return p2;
    } 
    
}
